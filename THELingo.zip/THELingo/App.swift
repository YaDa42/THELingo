import SwiftUI

@main
struct THELingoApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
