import SwiftUI

// MARK: - Languages

enum AppLanguage: String, CaseIterable, Identifiable {
    case en = "EN"
    case ru = "RU"
    case es = "SP"
    case zh = "CH"
    case ja = "JP"

    var id: String { rawValue }
}

enum StudyCourse: String, CaseIterable, Identifiable {
    case english, spanish, japanese, chinese, russian

    var id: String { rawValue }

    var flag: String {
        switch self {
        case .english: "🇬🇧"
        case .spanish: "🇪🇸"
        case .japanese: "🇯🇵"
        case .chinese: "🇨🇳"
        case .russian: "🇷🇺"
        }
    }

    func title(_ language: AppLanguage) -> String {
        switch self {
        case .english:
            ["EN":"English","RU":"Английский","SP":"Inglés","CH":"英语","JP":"英語"][language.rawValue]!
        case .spanish:
            ["EN":"Spanish","RU":"Испанский","SP":"Español","CH":"西班牙语","JP":"スペイン語"][language.rawValue]!
        case .japanese:
            ["EN":"Japanese","RU":"Японский","SP":"Japonés","CH":"日语","JP":"日本語"][language.rawValue]!
        case .chinese:
            ["EN":"Chinese","RU":"Китайский","SP":"Chino","CH":"中文","JP":"中国語"][language.rawValue]!
        case .russian:
            ["EN":"Russian","RU":"Русский","SP":"Ruso","CH":"俄语","JP":"ロシア語"][language.rawValue]!
        }
    }

    var targetLanguage: AppLanguage {
        switch self {
        case .english: .en
        case .spanish: .es
        case .japanese: .ja
        case .chinese: .zh
        case .russian: .ru
        }
    }
}

// MARK: - Vocabulary

struct Word {
    let translations: [AppLanguage: String]

    func get(_ language: AppLanguage) -> String {
        translations[language] ?? ""
    }
}

let vocabulary: [Word] = [
    Word(translations: [.en:"Hello",.ru:"Привет",.es:"Hola",.zh:"你好",.ja:"こんにちは"]),
    Word(translations: [.en:"Goodbye",.ru:"Пока",.es:"Adiós",.zh:"再见",.ja:"さようなら"]),
    Word(translations: [.en:"Thank you",.ru:"Спасибо",.es:"Gracias",.zh:"谢谢",.ja:"ありがとう"]),
    Word(translations: [.en:"Please",.ru:"Пожалуйста",.es:"Por favor",.zh:"请",.ja:"お願いします"]),
    Word(translations: [.en:"Water",.ru:"Вода",.es:"Agua",.zh:"水",.ja:"水"]),
    Word(translations: [.en:"Bread",.ru:"Хлеб",.es:"Pan",.zh:"面包",.ja:"パン"]),
    Word(translations: [.en:"Apple",.ru:"Яблоко",.es:"Manzana",.zh:"苹果",.ja:"りんご"]),
    Word(translations: [.en:"House",.ru:"Дом",.es:"Casa",.zh:"房子",.ja:"家"]),
    Word(translations: [.en:"School",.ru:"Школа",.es:"Escuela",.zh:"学校",.ja:"学校"]),
    Word(translations: [.en:"Book",.ru:"Книга",.es:"Libro",.zh:"书",.ja:"本"]),
    Word(translations: [.en:"Friend",.ru:"Друг",.es:"Amigo",.zh:"朋友",.ja:"友達"]),
    Word(translations: [.en:"Family",.ru:"Семья",.es:"Familia",.zh:"家庭",.ja:"家族"]),
    Word(translations: [.en:"Cat",.ru:"Кот",.es:"Gato",.zh:"猫",.ja:"猫"]),
    Word(translations: [.en:"Dog",.ru:"Собака",.es:"Perro",.zh:"狗",.ja:"犬"]),
    Word(translations: [.en:"Red",.ru:"Красный",.es:"Rojo",.zh:"红色",.ja:"赤"]),
    Word(translations: [.en:"Green",.ru:"Зелёный",.es:"Verde",.zh:"绿色",.ja:"緑"]),
    Word(translations: [.en:"Blue",.ru:"Синий",.es:"Azul",.zh:"蓝色",.ja:"青"]),
    Word(translations: [.en:"One",.ru:"Один",.es:"Uno",.zh:"一",.ja:"一"]),
    Word(translations: [.en:"Two",.ru:"Два",.es:"Dos",.zh:"二",.ja:"二"]),
    Word(translations: [.en:"Three",.ru:"Три",.es:"Tres",.zh:"三",.ja:"三"]),
    Word(translations: [.en:"Good",.ru:"Хороший",.es:"Bueno",.zh:"好",.ja:"良い"]),
    Word(translations: [.en:"Big",.ru:"Большой",.es:"Grande",.zh:"大",.ja:"大きい"]),
    Word(translations: [.en:"Small",.ru:"Маленький",.es:"Pequeño",.zh:"小",.ja:"小さい"]),
    Word(translations: [.en:"Today",.ru:"Сегодня",.es:"Hoy",.zh:"今天",.ja:"今日"]),
    Word(translations: [.en:"Tomorrow",.ru:"Завтра",.es:"Mañana",.zh:"明天",.ja:"明日"]),
    Word(translations: [.en:"I",.ru:"Я",.es:"Yo",.zh:"我",.ja:"私"]),
    Word(translations: [.en:"You",.ru:"Ты",.es:"Tú",.zh:"你",.ja:"あなた"]),
    Word(translations: [.en:"Eat",.ru:"Есть",.es:"Comer",.zh:"吃",.ja:"食べる"]),
    Word(translations: [.en:"Read",.ru:"Читать",.es:"Leer",.zh:"读",.ja:"読む"]),
    Word(translations: [.en:"Learn",.ru:"Учиться",.es:"Aprender",.zh:"学习",.ja:"学ぶ"])
]

// MARK: - Sentences

struct Sentence {
    let translations: [AppLanguage: String]

    func get(_ language: AppLanguage) -> String {
        translations[language] ?? ""
    }
}

let sentences: [Sentence] = [
    Sentence(translations: [.en:"I like apples",.ru:"Я люблю яблоки",.es:"Me gustan las manzanas",.zh:"我喜欢苹果",.ja:"私はりんごが好きです"]),
    Sentence(translations: [.en:"The cat is small",.ru:"Кот маленький",.es:"El gato es pequeño",.zh:"猫很小",.ja:"猫は小さいです"]),
    Sentence(translations: [.en:"I read a book",.ru:"Я читаю книгу",.es:"Leo un libro",.zh:"我读一本书",.ja:"私は本を読みます"]),
    Sentence(translations: [.en:"I drink water",.ru:"Я пью воду",.es:"Bebo agua",.zh:"我喝水",.ja:"私は水を飲みます"]),
    Sentence(translations: [.en:"This is my house",.ru:"Это мой дом",.es:"Esta es mi casa",.zh:"这是我的家",.ja:"これは私の家です"]),
    Sentence(translations: [.en:"We learn every day",.ru:"Мы учимся каждый день",.es:"Aprendemos todos los días",.zh:"我们每天学习",.ja:"私たちは毎日勉強します"])
]

// MARK: - Helpers

func clean(_ value: String) -> String {
    value.lowercased()
        .trimmingCharacters(in: .whitespacesAndNewlines)
        .replacingOccurrences(of: ".", with: "")
        .replacingOccurrences(of: "!", with: "")
        .replacingOccurrences(of: "?", with: "")
        .replacingOccurrences(of: "。", with: "")
}

func makeOptions(correct: String, seed: Int, language: AppLanguage) -> [String] {
    let alternatives = vocabulary
        .map { $0.get(language) }
        .filter { clean($0) != clean(correct) }

    var result = Array(alternatives.shuffled().prefix(3))
    result.append(correct)
    return result.shuffled()
}

// MARK: - Main View

struct ContentView: View {

    @AppStorage("profileName") var profileName = ""
    @AppStorage("didRegister") var didRegister = false
    @AppStorage("birthDate") var birthDate = ""
    @AppStorage("totalXP") var totalXP = 0
    @AppStorage("completedIDs") var completedIDs = ""
    @AppStorage("appLanguage") var appLanguage = "EN"

    @State private var nameInput = ""
    @State private var birthInput = Date()

    private var language: AppLanguage {
        AppLanguage(rawValue: appLanguage) ?? .en
    }

    private var completed: Set<String> {
        Set(completedIDs.split(separator: ",").map(String.init))
    }

    private var boost: Int {
        completed.count >= 6 ? 3 : completed.count >= 3 ? 2 : 1
    }

    var body: some View {
        Group {
            if didRegister {
                MainTabs(
                    language: language,
                    name: profileName,
                    totalXP: totalXP,
                    completed: completed,
                    boost: boost
                )
            } else {
                registration
            }
        }
        .tint(.green)
        .preferredColorScheme(.light)
    }

    var registration: some View {
        VStack(spacing: 22) {
            Spacer()

            Text("🌱").font(.system(size: 65))
            Text("THELingo").font(.system(size: 38, weight: .heavy))
            Text("Create your profile").font(.title2.bold())

            TextField("Your name", text: $nameInput)
                .textFieldStyle(.roundedBorder)

            DatePicker(
                "Date of birth",
                selection: $birthInput,
                displayedComponents: .date
            )

            Picker("Language", selection: $appLanguage) {
                ForEach(AppLanguage.allCases) {
                    Text($0.rawValue).tag($0.rawValue)
                }
            }
            .pickerStyle(.segmented)

            Button("Continue") {
                let name = nameInput.trimmingCharacters(in: .whitespaces)
                guard !name.isEmpty else { return }

                profileName = name
                birthDate = birthInput.formatted(date: .numeric, time: .omitted)
                didRegister = true
            }
            .buttonStyle(.borderedProminent)
            .disabled(nameInput.trimmingCharacters(in: .whitespaces).isEmpty)

            Spacer()
        }
        .padding(25)
    }
}

// MARK: - Tabs

struct MainTabs: View {
    let language: AppLanguage
    let name: String
    let totalXP: Int
    let completed: Set<String>
    let boost: Int

    var body: some View {
        TabView {
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Hey! \(name) 👋")
                            .font(.largeTitle.bold())

                        Text("Choose your course")
                            .foregroundStyle(.secondary)

                        HStack {
                            stat("⭐", "\(totalXP)", "XP")
                            stat("⚡", "×\(boost)", "BOOST")
                        }

                        ForEach(StudyCourse.allCases) { course in
                            NavigationLink {
                                CourseView(
                                    course: course,
                                    language: language,
                                    completed: completed
                                )
                            } label: {
                                HStack(spacing: 15) {
                                    Text(course.flag)
                                        .font(.system(size: 42))

                                    VStack(alignment: .leading) {
                                        Text(course.title(language))
                                            .font(.title3.bold())
                                            .foregroundStyle(.primary)

                                        Text("1,024 lessons · 4 tasks each")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }

                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundStyle(.secondary)
                                }
                                .padding()
                                .background(.white)
                                .clipShape(RoundedRectangle(cornerRadius: 16))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding()
                }
                .navigationTitle("THELingo")
            }
            .tabItem {
                Label("Выбор курсов", systemImage: "books.vertical.fill")
            }

            NavigationStack {
                VStack(spacing: 20) {
                    Text("🏆").font(.system(size: 60))
                    Text("\(totalXP) XP").font(.largeTitle.bold())
                    Text("\(completed.count) lessons completed")
                    Text("XP BOOST ×\(boost)").font(.title2.bold())
                    Text("3 lessons = ×2 XP\n6 lessons = ×3 XP")
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                .padding()
                .navigationTitle("Progress")
            }
            .tabItem {
                Label("Прогресс", systemImage: "chart.bar.fill")
            }

            NavigationStack {
                Form {
                    Text("👤 \(name)")
                    Text("Language: \(language.rawValue)")
                }
                .navigationTitle("Profile")
            }
            .tabItem {
                Label("Профиль", systemImage: "person.fill")
            }
        }
    }

    func stat(_ emoji: String, _ value: String, _ title: String) -> some View {
        VStack(alignment: .leading) {
            Text(emoji).font(.title)
            Text(value).font(.largeTitle.bold())
            Text(title).font(.caption)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

// MARK: - Course

struct CourseView: View {
    let course: StudyCourse
    let language: AppLanguage
    let completed: Set<String>

    var body: some View {
        List {
            Section {
                HStack {
                    Text(course.flag).font(.largeTitle)
                    Text(course.title(language)).font(.title2.bold())
                }
            }

            Section("Lessons") {
                ForEach(1...1024, id: \.self) { number in
                    NavigationLink {
                        LessonView(
                            course: course,
                            language: language,
                            number: number
                        )
                    } label: {
                        HStack {
                            Text("Lesson \(number)")
                            Spacer()
                            if completed.contains("\(course.rawValue)-\(number)") {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle(course.title(language))
    }
}

// MARK: - Lesson

struct LessonView: View {
    let course: StudyCourse
    let language: AppLanguage
    let number: Int

    @AppStorage("totalXP") var totalXP = 0
    @AppStorage("completedIDs") var completedIDs = ""

    @Environment(\.dismiss) var dismiss

    @State private var taskIndex = 0
    @State private var answer = ""
    @State private var selected = ""
    @State private var builtWords: [String] = []
    @State private var checked = false
    @State private var correct = false
    @State private var finished = false

    private var word: Word {
        vocabulary[(number * 3 + taskIndex) % vocabulary.count]
    }

    private var sentence: Sentence {
        sentences[(number + taskIndex) % sentences.count]
    }

    private var source: String {
        word.get(course.targetLanguage)
    }

    private var translation: String {
        word.get(language)
    }

    private var sourceSentence: String {
        sentence.get(course.targetLanguage)
    }

    private var translatedSentence: String {
        sentence.get(language)
    }

    private var lessonID: String {
        "\(course.rawValue)-\(number)"
    }

    private var options: [String] {
        makeOptions(
            correct: translation,
            seed: number + taskIndex,
            language: language
        )
    }

    private var sentenceParts: [String] {
        sourceSentence.components(separatedBy: " ")
    }

    private var expected: String {
        switch taskIndex {
        case 0: translation
        case 1: translation
        case 2: sentenceParts.joined(separator: " ")
        default: translatedSentence
        }
    }

    private var currentAnswer: String {
        switch taskIndex {
        case 0: selected
        case 2: builtWords.joined(separator: " ")
        default: answer
        }
    }

    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                }

                ProgressView(value: Double(taskIndex + 1), total: 4)

                Text("\(taskIndex + 1)/4")
            }
            .padding()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text(course.flag)
                        .font(.largeTitle)

                    Text(taskTitle)
                        .font(.title.bold())

                    Text(taskPrompt)
                        .font(.title3.bold())

                    if taskIndex == 0 {
                        ForEach(options, id: \.self) { option in
                            Button {
                                selected = option
                            } label: {
                                HStack {
                                    Text(option)
                                    Spacer()
                                    if selected == option {
                                        Image(systemName: "checkmark.circle.fill")
                                    }
                                }
                                .padding()
                                .background(
                                    selected == option
                                    ? Color.green.opacity(0.2)
                                    : Color.white
                                )
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    else if taskIndex == 2 {
                        Text(builtWords.joined(separator: " "))
                            .frame(maxWidth: .infinity, minHeight: 60)
                            .padding()
                            .background(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 14))

                        ForEach(sentenceParts.shuffled(), id: \.self) { part in
                            Button(part) {
                                builtWords.append(part)
                            }
                            .buttonStyle(.bordered)
                        }

                        Button("Clear") {
                            builtWords = []
                        }
                    }

                    else {
                        TextField("Write your answer...", text: $answer)
                            .textFieldStyle(.roundedBorder)
                            .font(.title3)
                    }

                    if checked {
                        Text(correct ? "Correct! 🎉" : "Try again!")
                            .font(.headline)
                            .foregroundStyle(correct ? .green : .orange)

                        if !correct {
                            Text("Correct answer: \(expected)")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding()
            }

            if finished {
                Button("Back to course") {
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }

            else if checked && correct {
                Button(taskIndex == 3 ? "Finish lesson" : "Continue") {
                    if taskIndex == 3 {
                        finishLesson()
                    } else {
                        taskIndex += 1
                        answer = ""
                        selected = ""
                        builtWords = []
                        checked = false
                        correct = false
                    }
                }
                .buttonStyle(.borderedProminent)
            }

            else {
                Button("Check answer") {
                    correct = clean(currentAnswer) == clean(expected)
                    checked = true
                }
                .buttonStyle(.borderedProminent)
                .disabled(currentAnswer.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
        .padding(.bottom)
        .navigationTitle("THELingo")
        .navigationBarBackButtonHidden()
        .onAppear {
            if completedIDs.split(separator: ",").contains(Substring(lessonID)) {
                finished = true
            }
        }
    }

    private var taskTitle: String {
        switch taskIndex {
        case 0: "Choose the translation"
        case 1: "Write the word"
        case 2: "Build the sentence"
        default: "Translate the sentence"
        }
    }

    private var taskPrompt: String {
        switch taskIndex {
        case 0: "What does \(source) mean?"
        case 1: "Write the translation of: \(source)"
        case 2: "Put the words in the correct order: \(sourceSentence)"
        default: "Translate into \(language.rawValue): \(sourceSentence)"
        }
    }

    private func finishLesson() {
        var ids = Set(completedIDs.split(separator: ",").map(String.init))

        guard !ids.contains(lessonID) else {
            finished = true
            return
        }

        let multiplier = ids.count >= 6 ? 3 : ids.count >= 3 ? 2 : 1

        totalXP += 10 * multiplier
        ids.insert(lessonID)
        completedIDs = ids.sorted().joined(separator: ",")

        finished = true
    }
}