
import SwiftUI

// MARK: - Languages

enum AppLanguage: String, CaseIterable, Identifiable {
    case en = "EN"
    case ru = "RU"
    case es = "SP"
    case zh = "CH"
    case ja = "JP"

    var id: String { rawValue }
}

func localized(
    _ en: String,
    _ ru: String,
    _ es: String,
    _ zh: String,
    _ ja: String
) -> [String: String] {
    [
        "EN": en,
        "RU": ru,
        "SP": es,
        "CH": zh,
        "JP": ja
    ]
}

// MARK: - Models

struct Lesson: Identifiable {
    let id: String
    let title: [String: String]
    let question: [String: String]
    let options: [[String: String]]
    let answer: Int
}

struct Course: Identifiable {
    let id: String
    let flag: String
    let title: [String: String]
    let lessons: [Lesson]
}

func lesson(
    _ id: String,
    _ title: String,
    _ question: String,
    _ correct: String,
    _ wrong1: String,
    _ wrong2: String
) -> Lesson {
    Lesson(
        id: id,
        title: localized(title, title, title, title, title),
        question: localized(question, question, question, question, question),
        options: [
            localized(correct, correct, correct, correct, correct),
            localized(wrong1, wrong1, wrong1, wrong1, wrong1),
            localized(wrong2, wrong2, wrong2, wrong2, wrong2)
        ],
        answer: 0
    )
}

// MARK: - Courses

let courses: [Course] = [

    Course(
        id: "english",
        flag: "🇬🇧",
        title: localized("English", "Английский", "Inglés", "英语", "英語"),
        lessons: [
            lesson("en1", "Greetings", "What does Hello mean?", "Привет", "Пока", "Спасибо"),
            lesson("en2", "Polite words", "What does Thank you mean?", "Спасибо", "Извини", "Пока"),
            lesson("en3", "Animals", "What does Cat mean?", "Кот", "Собака", "Птица"),
            lesson("en4", "Numbers", "What does Three mean?", "Три", "Пять", "Два"),
            lesson("en5", "Food", "What does Apple mean?", "Яблоко", "Хлеб", "Вода"),
            lesson("en6", "Colors", "What does Green mean?", "Зелёный", "Синий", "Красный"),
            lesson("en7", "Family", "What does Mother mean?", "Мама", "Папа", "Сестра"),
            lesson("en8", "Daily phrases", "What does Good morning mean?", "Доброе утро", "Спокойной ночи", "До свидания")
        ]
    ),

    Course(
        id: "spanish",
        flag: "🇪🇸",
        title: localized("Spanish", "Испанский", "Español", "西班牙语", "スペイン語"),
        lessons: [
            lesson("es1", "Greetings", "What does Hola mean?", "Привет", "Пока", "Спасибо"),
            lesson("es2", "Polite words", "What does Gracias mean?", "Спасибо", "Извини", "Пока"),
            lesson("es3", "Numbers", "What does Uno mean?", "Один", "Два", "Три"),
            lesson("es4", "Animals", "What does Perro mean?", "Собака", "Кот", "Птица"),
            lesson("es5", "Food", "What does Agua mean?", "Вода", "Хлеб", "Молоко"),
            lesson("es6", "Colors", "What does Rojo mean?", "Красный", "Синий", "Зелёный"),
            lesson("es7", "Family", "What does Madre mean?", "Мама", "Папа", "Брат"),
            lesson("es8", "Daily phrases", "What does Buenos días mean?", "Доброе утро", "Спокойной ночи", "Пока")
        ]
    ),

    Course(
        id: "japanese",
        flag: "🇯🇵",
        title: localized("Japanese", "Японский", "Japonés", "日语", "日本語"),
        lessons: [
            lesson("ja1", "Greetings", "What does こんにちは mean?", "Привет", "Пока", "Спасибо"),
            lesson("ja2", "Thanks", "What does ありがとう mean?", "Спасибо", "Извини", "Пожалуйста"),
            lesson("ja3", "Numbers", "What does いち mean?", "Один", "Два", "Три"),
            lesson("ja4", "Food", "What does 水 mean?", "Вода", "Рис", "Чай"),
            lesson("ja5", "Animals", "What does ねこ mean?", "Кот", "Собака", "Птица"),
            lesson("ja6", "Polite words", "What does すみません mean?", "Извините", "Спасибо", "Пока"),
            lesson("ja7", "Colors", "What does あお mean?", "Синий", "Красный", "Зелёный"),
            lesson("ja8", "Daily phrases", "What does おやすみ mean?", "Спокойной ночи", "Привет", "Спасибо")
        ]
    ),

    Course(
        id: "chinese",
        flag: "🇨🇳",
        title: localized("Chinese", "Китайский", "Chino", "中文", "中国語"),
        lessons: [
            lesson("zh1", "Greetings", "What does 你好 mean?", "Привет", "Пока", "Спасибо"),
            lesson("zh2", "Thanks", "What does 谢谢 mean?", "Спасибо", "Извини", "Пожалуйста"),
            lesson("zh3", "Numbers", "What does 三 mean?", "Три", "Один", "Пять"),
            lesson("zh4", "Food", "What does 水 mean?", "Вода", "Рис", "Чай"),
            lesson("zh5", "Animals", "What does 猫 mean?", "Кот", "Собака", "Птица"),
            lesson("zh6", "Colors", "What does 绿色 mean?", "Зелёный", "Синий", "Красный"),
            lesson("zh7", "Family", "What does 妈妈 mean?", "Мама", "Папа", "Друг"),
            lesson("zh8", "Daily phrases", "What does 晚安 mean?", "Спокойной ночи", "Доброе утро", "Привет")
        ]
    )
]

// MARK: - Main View

struct ContentView: View {

    @AppStorage("profileName") private var profileName = ""
    @AppStorage("birthDate") private var birthDate = ""
    @AppStorage("didRegister") private var didRegister = false
    @AppStorage("totalXP") private var totalXP = 0
    @AppStorage("completedIDs") private var completedIDs = ""
    @AppStorage("appLanguage") private var appLanguage = "EN"

    @State private var nameInput = ""
    @State private var birthInput = Date()
    @State private var selectedTab = 0

    private var lang: AppLanguage {
        AppLanguage(rawValue: appLanguage) ?? .en
    }

    private var completed: Set<String> {
        Set(completedIDs.split(separator: ",").map(String.init))
    }

    private var lessonCount: Int {
        completed.count
    }

    private var boost: Int {
        if lessonCount >= 6 { return 3 }
        if lessonCount >= 3 { return 2 }
        return 1
    }

    private func text(
        _ en: String,
        _ ru: String,
        _ es: String,
        _ zh: String,
        _ ja: String
    ) -> String {
        localized(en, ru, es, zh, ja)[lang.rawValue] ?? en
    }

    var body: some View {
        Group {
            if didRegister {
                mainTabs
            } else {
                registration
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color(red: 0.95, green: 0.98, blue: 0.95)
                .ignoresSafeArea()
        )
        .tint(.green)
        .preferredColorScheme(.light)
    }

    // MARK: Registration

    private var registration: some View {
        ScrollView {
            VStack(spacing: 22) {
                Text("🌱")
                    .font(.system(size: 65))

                Text("THELingo")
                    .font(.system(size: 38, weight: .heavy))

                Text(text(
                    "Create your profile",
                    "Создай профиль",
                    "Crea tu perfil",
                    "创建个人资料",
                    "プロフィールを作成"
                ))
                .font(.title2.bold())

                TextField(
                    text("Your name", "Твоё имя", "Tu nombre", "你的名字", "名前"),
                    text: $nameInput
                )
                .padding()
                .background(.white)
                .clipShape(RoundedRectangle(cornerRadius: 15))

                DatePicker(
                    text("Date of birth", "Дата рождения", "Fecha de nacimiento", "出生日期", "生年月日"),
                    selection: $birthInput,
                    displayedComponents: .date
                )
                .padding()
                .background(.white)
                .clipShape(RoundedRectangle(cornerRadius: 15))

                Picker("Language", selection: $appLanguage) {
                    ForEach(AppLanguage.allCases) { language in
                        Text(language.rawValue).tag(language.rawValue)
                    }
                }
                .pickerStyle(.segmented)

                Button {
                    let name = nameInput.trimmingCharacters(in: .whitespaces)
                    guard !name.isEmpty else { return }

                    profileName = name
                    birthDate = birthInput.formatted(date: .numeric, time: .omitted)
                    didRegister = true
                } label: {
                    Text(text(
                        "Continue",
                        "Продолжить",
                        "Continuar",
                        "继续",
                        "続ける"
                    ))
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(nameInput.isEmpty ? .gray : .green)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                }
                .disabled(nameInput.trimmingCharacters(in: .whitespaces).isEmpty)

                Text("No email required")
                    .foregroundStyle(.secondary)
            }
            .padding(24)
            .frame(maxWidth: 600)
            .frame(maxWidth: .infinity)
        }
        .background(Color(red: 0.95, green: 0.98, blue: 0.95))
    }

    // MARK: Tabs

    private var mainTabs: some View {
        TabView(selection: $selectedTab) {

            coursesScreen
                .tabItem {
                    Label(
                        text("Courses", "Выбор курсов", "Cursos", "课程", "コース"),
                        systemImage: "books.vertical.fill"
                    )
                }
                .tag(0)

            progressScreen
                .tabItem {
                    Label(
                        text("Progress", "Прогресс", "Progreso", "进度", "進捗"),
                        systemImage: "chart.bar.fill"
                    )
                }
                .tag(1)

            profileScreen
                .tabItem {
                    Label(
                        text("Profile", "Профиль", "Perfil", "个人资料", "プロフィール"),
                        systemImage: "person.fill"
                    )
                }
                .tag(2)
        }
    }

    // MARK: Courses

    private var coursesScreen: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    HStack {
                        VStack(alignment: .leading) {
                            Text("Hey! \(profileName) 👋")
                                .font(.system(size: 27, weight: .bold))

                            Text(text(
                                "Choose your course",
                                "Выбери курс",
                                "Elige un curso",
                                "选择课程",
                                "コースを選ぼう"
                            ))
                            .foregroundStyle(.secondary)
                        }

                        Spacer()
                        Text("🌿")
                            .font(.largeTitle)
                    }

                    HStack(spacing: 12) {
                        statistic("⭐", "\(totalXP)", "Total XP")
                        statistic("⚡", "×\(boost)", "XP BOOST")
                    }

                    ForEach(courses) { course in
                        NavigationLink {
                            CourseScreen(
                                course: course,
                                lang: lang,
                                completed: completed,
                                onComplete: completeLesson
                            )
                        } label: {
                            HStack(spacing: 15) {
                                Text(course.flag)
                                    .font(.system(size: 42))

                                VStack(alignment: .leading, spacing: 6) {
                                    Text(course.title[lang.rawValue] ?? course.title["EN"]!)
                                        .font(.title3.bold())
                                        .foregroundStyle(.primary)

                                    Text("\(course.lessons.count) lessons")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }

                                Spacer()

                                Image(systemName: "chevron.right")
                                    .foregroundStyle(.secondary)
                            }
                            .padding(18)
                            .background(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 18))
                            .overlay {
                                RoundedRectangle(cornerRadius: 18)
                                    .stroke(.green.opacity(0.2))
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(17)
                .frame(maxWidth: 650)
                .frame(maxWidth: .infinity)
            }
            .background(Color(red: 0.95, green: 0.98, blue: 0.95))
            .navigationTitle("THELingo")
        }
    }

    private func statistic(
        _ emoji: String,
        _ value: String,
        _ label: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(emoji)
                .font(.title)

            Text(value)
                .font(.largeTitle.bold())

            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(.white)
        .clipShape(RoundedRectangle(cornerRadius: 17))
    }

    // MARK: Progress

    private var progressScreen: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("🏆")
                    .font(.system(size: 65))

                Text("\(totalXP) XP")
                    .font(.largeTitle.bold())

                Text("\(lessonCount) lessons completed")
                    .foregroundStyle(.secondary)

                Text("XP BOOST ×\(boost)")
                    .font(.title2.bold())
                    .padding()
                    .background(.green.opacity(0.15))
                    .clipShape(Capsule())

                ProgressView(
                    value: min(Double(lessonCount), 6),
                    total: 6
                )
                .padding(.horizontal)

                Text("3 lessons = ×2 XP\n6 lessons = ×3 XP")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)

                Spacer()
            }
            .padding()
            .navigationTitle("Progress")
        }
    }

    // MARK: Profile

    private var profileScreen: some View {
        NavigationStack {
            Form {
                Section("THELingo") {
                    Text("👤 \(profileName)")
                    Text("🎂 \(birthDate)")

                    Picker("Language", selection: $appLanguage) {
                        ForEach(AppLanguage.allCases) { language in
                            Text(language.rawValue).tag(language.rawValue)
                        }
                    }
                }

                Section {
                    Button("Reset progress", role: .destructive) {
                        totalXP = 0
                        completedIDs = ""
                    }
                }
            }
            .navigationTitle("Profile")
        }
    }

    // MARK: XP

    private func completeLesson(_ lesson: Lesson) {
        var ids = completed

        guard !ids.contains(lesson.id) else { return }

        let multiplier: Int

        if ids.count >= 6 {
            multiplier = 3
        } else if ids.count >= 3 {
            multiplier = 2
        } else {
            multiplier = 1
        }

        totalXP += 10 * multiplier

        ids.insert(lesson.id)
        completedIDs = ids.sorted().joined(separator: ",")
    }
}

// MARK: - Course Screen

struct CourseScreen: View {

    let course: Course
    let lang: AppLanguage
    let completed: Set<String>
    let onComplete: (Lesson) -> Void

    var body: some View {
        ScrollView {
            VStack(spacing: 14) {

                HStack {
                    Text(course.flag)
                        .font(.system(size: 48))

                    Text(course.title[lang.rawValue] ?? course.title["EN"]!)
                        .font(.title.bold())

                    Spacer()
                }

                ForEach(
                    Array(course.lessons.enumerated()),
                    id: \.element.id
                ) { index, item in

                    NavigationLink {
                        LessonScreen(
                            lesson: item,
                            lang: lang,
                            alreadyCompleted: completed.contains(item.id),
                            onComplete: onComplete
                        )
                    } label: {
                        HStack {
                            ZStack {
                                Circle()
                                    .fill(.green.opacity(0.15))
                                    .frame(width: 44, height: 44)

                                if completed.contains(item.id) {
                                    Image(systemName: "checkmark")
                                        .foregroundStyle(.green)
                                } else {
                                    Text("\(index + 1)")
                                        .font(.headline)
                                        .foregroundStyle(.primary)
                                }
                            }

                            VStack(alignment: .leading) {
                                Text(item.title[lang.rawValue] ?? item.title["EN"]!)
                                    .font(.headline)
                                    .foregroundStyle(.primary)

                                Text(
                                    completed.contains(item.id)
                                    ? "Completed"
                                    : "+10 XP"
                                )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }

                            Spacer()

                            Image(systemName: "chevron.right")
                                .foregroundStyle(.secondary)
                        }
                        .padding()
                        .background(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding()
        }
        .background(Color(red: 0.95, green: 0.98, blue: 0.95))
        .navigationTitle(course.title[lang.rawValue] ?? course.title["EN"]!)
    }
}

// MARK: - Lesson Screen

struct LessonScreen: View {

    let lesson: Lesson
    let lang: AppLanguage
    let alreadyCompleted: Bool
    let onComplete: (Lesson) -> Void

    @Environment(\.dismiss) private var dismiss

    @State private var selected: Int?
    @State private var checked = false
    @State private var finished = false

    private var isCorrect: Bool {
        selected == lesson.answer
    }

    var body: some View {
        VStack(spacing: 0) {

            ScrollView {
                VStack(spacing: 24) {

                    Text("✨")
                        .font(.system(size: 55))
                        .padding(.top, 20)

                    Text(lesson.title[lang.rawValue] ?? lesson.title["EN"]!)
                        .font(.largeTitle.bold())
                        .multilineTextAlignment(.center)

                    Text(lesson.question[lang.rawValue] ?? lesson.question["EN"]!)
                        .font(.title2.bold())
                        .multilineTextAlignment(.center)
                        .padding(.vertical, 12)

                    ForEach(lesson.options.indices, id: \.self) { index in

                        Button {
                            selected = index
                            checked = false
                        } label: {

                            HStack {
                                Text(
                                    lesson.options[index][lang.rawValue]
                                    ?? lesson.options[index]["EN"]!
                                )
                                .font(.title3.bold())

                                Spacer()

                                if selected == index {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(.green)
                                }
                            }
                            .padding(20)
                            .frame(maxWidth: .infinity, minHeight: 76)
                            .background(
                                selected == index
                                ? Color.green.opacity(0.15)
                                : Color.white
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 20))
                            .overlay {
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(
                                        selected == index
                                        ? Color.green
                                        : Color.gray.opacity(0.2),
                                        lineWidth: 2
                                    )
                            }
                        }
                        .buttonStyle(.plain)
                        .disabled(finished)
                    }

                    if checked {
                        Text(isCorrect ? "Correct! 🎉" : "Try again!")
                            .font(.headline)
                            .foregroundStyle(isCorrect ? .green : .orange)
                    }
                }
                .padding(22)
            }

            VStack(spacing: 12) {

                if finished {

                    Button("Back to course") {
                        dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)

                } else if checked && isCorrect {

                    Button("Finish lesson") {
                        onComplete(lesson)
                        finished = true
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)

                } else {

                    Button("Check answer") {
                        checked = true
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .disabled(selected == nil)
                }
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color(red: 0.95, green: 0.98, blue: 0.95))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.95, green: 0.98, blue: 0.95))
        .navigationTitle("THELingo")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.hidden, for: .tabBar)
        .onAppear {
            if alreadyCompleted {
                finished = true
            }
        }
    }
}
