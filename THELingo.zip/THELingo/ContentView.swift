import SwiftUI

private enum AppLanguage: String, CaseIterable, Identifiable {
    case en = "EN", ru = "RU", es = "SP", zh = "CH", ja = "JP"
    var id: String { rawValue }
}

private struct Course: Identifiable {
    let id: String
    let flag: String
    let title: [String: String]
    let subtitle: [String: String]
    let lessons: [Lesson]
}

private struct Lesson: Identifiable {
    let id: String
    let title: [String: String]
    let prompt: [String: String]
    let options: [String]
    let answer: String
}

struct ContentView: View {
    @AppStorage("profileName") private var profileName = ""
    @AppStorage("birthDate") private var birthDate = ""
    @AppStorage("didRegister") private var didRegister = false
    @AppStorage("totalXP") private var totalXP = 0
    @AppStorage("completedLessons") private var completedLessons = 0
    @AppStorage("selectedLanguage") private var selectedLanguage = "EN"
    @AppStorage("completedCourseIDs") private var completedCourseIDs = ""

    @State private var nameInput = ""
    @State private var birthInput = Date()
    @State private var activeLesson: Lesson?
    @State private var selectedAnswer = ""
    @State private var showResult = false
    @State private var lessonFinished = false
    @State private var selectedTab = 0

    private var lang: AppLanguage { AppLanguage(rawValue: selectedLanguage) ?? .en }
    private var multiplier: Int { completedLessons >= 6 ? 3 : (completedLessons >= 3 ? 2 : 1) }
    private var completedIDs: Set<String> { Set(completedCourseIDs.split(separator: ",").map(String.init)) }

    private let courses: [Course] = [
        Course(id: "english", flag: "🇬🇧", title: ["EN":"English","RU":"Английский","SP":"Inglés","CH":"英语","JP":"英語"], subtitle: ["EN":"Start speaking today","RU":"Начни говорить сегодня","SP":"Empieza hoy","CH":"今天开始学习","JP":"今日から始めよう"], lessons: [
            Lesson(id:"hello", title:["EN":"First words","RU":"Первые слова","SP":"Primeras palabras","CH":"第一个单词","JP":"最初の単語"], prompt:["EN":"What does “Hello” mean?","RU":"Что значит “Hello”?","SP":"¿Qué significa “Hello”?","CH":"“Hello”是什么意思？","JP":"“Hello”はどういう意味？"], options:["Привет","Пока","Спасибо"], answer:"Привет"),
            Lesson(id:"thanks", title:["EN":"Be polite","RU":"Вежливые слова","SP":"Sé amable","CH":"礼貌用语","JP":"丁寧な言葉"], prompt:["EN":"Choose the meaning of “Thank you”","RU":"Выбери перевод “Thank you”","SP":"Elige el significado de “Thank you”","CH":"选择“Thank you”的意思","JP":"“Thank you”の意味を選ぼう"], options:["Пожалуйста","Спасибо","Извини"], answer:"Спасибо"),
            Lesson(id:"cat", title:["EN":"Animals","RU":"Животные","SP":"Animales","CH":"动物","JP":"動物"], prompt:["EN":"What is a “Cat”?","RU":"Что такое “Cat”?","SP":"¿Qué es “Cat”?","CH":"“Cat”是什么？","JP":"“Cat”は何？"], options:["Собака","Кот","Птица"], answer:"Кот")
        ]),
        Course(id: "spanish", flag: "🇪🇸", title: ["EN":"Spanish","RU":"Испанский","SP":"Español","CH":"西班牙语","JP":"スペイン語"], subtitle: ["EN":"Hola! Learn step by step","RU":"¡Hola! Учись шаг за шагом","SP":"¡Hola! Aprende paso a paso","CH":"你好！循序渐进","JP":"¡Hola! 一歩ずつ学ぼう"], lessons: [
            Lesson(id:"hola", title:["EN":"Greetings","RU":"Приветствия","SP":"Saludos","CH":"问候","JP":"あいさつ"], prompt:["EN":"What does “Hola” mean?","RU":"Что значит “Hola”?","SP":"¿Qué significa “Hola”?","CH":"“Hola”是什么意思？","JP":"“Hola”はどういう意味？"], options:["Привет","Спасибо","До свидания"], answer:"Привет")
        ]),
        Course(id: "japanese", flag: "🇯🇵", title: ["EN":"Japanese","RU":"Японский","SP":"Japonés","CH":"日语","JP":"日本語"], subtitle: ["EN":"Discover a new alphabet","RU":"Открой новую письменность","SP":"Descubre un alfabeto","CH":"探索新文字","JP":"新しい文字を学ぼう"], lessons: [
            Lesson(id:"konnichiwa", title:["EN":"First greeting","RU":"Первое приветствие","SP":"Primer saludo","CH":"第一个问候","JP":"最初のあいさつ"], prompt:["EN":"What does “こんにちは” mean?","RU":"Что значит “こんにちは”?","SP":"¿Qué significa “こんにちは”?","CH":"“こんにちは”是什么意思？","JP":"「こんにちは」の意味は？"], options:["Привет","Спасибо","Спокойной ночи"], answer:"Привет")
        ]),
        Course(id: "chinese", flag: "🇨🇳", title: ["EN":"Chinese","RU":"Китайский","SP":"Chino","CH":"中文","JP":"中国語"], subtitle: ["EN":"Your first Mandarin steps","RU":"Первые шаги в китайском","SP":"Tus primeros pasos","CH":"普通话入门","JP":"中国語の第一歩"], lessons: [
            Lesson(id:"nihao", title:["EN":"Say hello","RU":"Скажи привет","SP":"Di hola","CH":"打招呼","JP":"こんにちはと言おう"], prompt:["EN":"What does “你好” mean?","RU":"Что значит “你好”?","SP":"¿Qué significa “你好”?","CH":"“你好”是什么意思？","JP":"「你好」の意味は？"], options:["Привет","Пока","Книга"], answer:"Привет")
        ])
    ]

    private func t(_ values: [String: String]) -> String { values[lang.rawValue] ?? values["EN"] ?? "" }
    private func word(_ key: String) -> String {
        let strings: [String: [String: String]] = [
            "learn":["EN":"Learn","RU":"Учёба","SP":"Aprender","CH":"学习","JP":"学習"],
            "progress":["EN":"Progress","RU":"Прогресс","SP":"Progreso","CH":"进度","JP":"進捗"],
            "profile":["EN":"Profile","RU":"Профиль","SP":"Perfil","CH":"个人资料","JP":"プロフィール"],
            "courses":["EN":"All courses","RU":"Все курсы","SP":"Todos los cursos","CH":"全部课程","JP":"すべてのコース"],
            "lessons":["EN":"lessons completed","RU":"уроков пройдено","SP":"lecciones completadas","CH":"已完成课程","JP":"レッスン完了"],
            "xp":["EN":"Total XP","RU":"Всего XP","SP":"XP total","CH":"总经验值","JP":"合計XP"],
            "start":["EN":"Start lesson","RU":"Начать урок","SP":"Empezar lección","CH":"开始课程","JP":"レッスン開始"],
            "register":["EN":"Create your profile","RU":"Создай профиль","SP":"Crea tu perfil","CH":"创建个人资料","JP":"プロフィールを作成"],
            "name":["EN":"Your name","RU":"Твоё имя","SP":"Tu nombre","CH":"你的名字","JP":"名前"],
            "birthday":["EN":"Date of birth","RU":"Дата рождения","SP":"Fecha de nacimiento","CH":"出生日期","JP":"生年月日"],
            "continue":["EN":"Continue","RU":"Продолжить","SP":"Continuar","CH":"继续","JP":"続ける"],
            "boost":["EN":"XP BOOST","RU":"БУСТ XP","SP":"IMPULSO XP","CH":"经验加成","JP":"XPブースト"],
            "correct":["EN":"Correct!","RU":"Правильно!","SP":"¡Correcto!","CH":"答对了！","JP":"正解！"],
            "wrong":["EN":"Not quite. Try again!","RU":"Почти! Попробуй ещё.","SP":"¡Inténtalo otra vez!","CH":"再试一次！","JP":"もう一度！"],
            "done":["EN":"Lesson complete!","RU":"Урок завершён!","SP":"¡Lección completada!","CH":"课程完成！","JP":"レッスン完了！"],
            "next":["EN":"Done","RU":"Готово","SP":"Listo","CH":"完成","JP":"完了"]
        ]
        return strings[key]?[lang.rawValue] ?? strings[key]?["EN"] ?? key
    }

    var body: some View {
        Group {
            if !didRegister {
                registrationView
            } else {
                mainView
            }
        }
        .tint(Color(red: 0.27, green: 0.72, blue: 0.47))
        .preferredColorScheme(.light)
    }

    private var registrationView: some View {
        VStack(spacing: 22) {
            Spacer()
            Text("🌱").font(.system(size: 64))
            Text("THELingo").font(.system(size: 36, weight: .heavy, design: .rounded))
            Text(word("register")).font(.title2.bold())
            VStack(spacing: 14) {
                TextField(word("name"), text: $nameInput)
                    .textContentType(.givenName).padding().background(Color.white).clipShape(RoundedRectangle(cornerRadius: 14))
                DatePicker(word("birthday"), selection: $birthInput, displayedComponents: .date)
                    .datePickerStyle(.compact).padding().background(Color.white).clipShape(RoundedRectangle(cornerRadius: 14))
                languagePicker
            }.padding(.horizontal, 26)
            Button {
                let clean = nameInput.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !clean.isEmpty else { return }
                profileName = clean
                birthDate = birthInput.formatted(date: .numeric, time: .omitted)
                didRegister = true
            } label: {
                Text(word("continue")).font(.headline).foregroundStyle(.white).frame(maxWidth: .infinity).padding()
                    .background(nameInput.trimmingCharacters(in: .whitespaces).isEmpty ? .gray : Color.green)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            }.disabled(nameInput.trimmingCharacters(in: .whitespaces).isEmpty).padding(.horizontal, 26)
            Spacer()
            Text("No email. Just your name and birthday.").font(.footnote).foregroundStyle(.secondary)
        }.padding().background(Color(red: 0.93, green: 0.98, blue: 0.94))
    }

    private var languagePicker: some View {
        HStack {
            Text("Language / Язык").font(.subheadline.weight(.semibold))
            Spacer()
            Picker("Language", selection: $selectedLanguage) {
                ForEach(AppLanguage.allCases) { Text($0.rawValue).tag($0.rawValue) }
            }.pickerStyle(.menu)
        }.padding().background(Color.white).clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private var mainView: some View {
        TabView(selection: $selectedTab) {
            homeView.tabItem { Label(word("learn"), systemImage: "book.fill") }.tag(0)
            progressView.tabItem { Label(word("progress"), systemImage: "chart.bar.fill") }.tag(1)
            profileView.tabItem { Label(word("profile"), systemImage: "person.fill") }.tag(2)
        }
        .sheet(item: $activeLesson) { lesson in lessonView(lesson) }
    }

    private var homeView: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Hey! \(profileName) 👋").font(.title.bold())
                            Text(word("courses")).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("🌿").font(.system(size: 36))
                    }
                    HStack(spacing: 12) {
                        statCard(value: "\(totalXP)", label: word("xp"), icon: "⭐")
                        statCard(value: "×\(multiplier)", label: word("boost"), icon: "⚡")
                    }
                    ForEach(courses) { course in
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(spacing: 14) {
                                Text(course.flag).font(.system(size: 38))
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(t(course.title)).font(.headline).foregroundStyle(.primary)
                                    Text(t(course.subtitle)).font(.subheadline).foregroundStyle(.secondary)
                                }
                                Spacer()
                            }
                            ForEach(course.lessons) { lesson in
                                Button { activeLesson = lesson } label: {
                                    HStack {
                                        Image(systemName: "play.circle.fill").foregroundStyle(.green)
                                        Text(t(lesson.title)).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                                        Spacer()
                                        Text(word("start")).font(.caption.bold()).foregroundStyle(.green)
                                    }.padding(.vertical, 8)
                                }.buttonStyle(.plain)
                            }
                        }.padding().background(.white).clipShape(RoundedRectangle(cornerRadius: 18))
                            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.green.opacity(0.15)))
                    }
                }.padding()
            }
            .background(Color(red: 0.96, green: 0.98, blue: 0.96))
            .navigationTitle("THELingo")
        }
    }

    private func statCard(value: String, label: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(icon).font(.title2)
            Text(value).font(.title.bold())
            Text(label).font(.caption).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding()
            .background(.white).clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var progressView: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Text("🏆").font(.system(size: 58))
                Text("\(totalXP) XP").font(.largeTitle.bold())
                Text("\(completedLessons) \(word("lessons"))").foregroundStyle(.secondary)
                Text("\(word("boost")): ×\(multiplier)").font(.headline).padding().background(Color.green.opacity(0.12)).clipShape(Capsule())
                ProgressView(value: min(Double(completedLessons), 6), total: 6).padding(.horizontal, 32)
                Text(completedLessons < 3 ? "3 урока → ×2 XP" : (completedLessons < 6 ? "6 уроков → ×3 XP" : "×3 XP unlocked!"))
                    .font(.subheadline).foregroundStyle(.secondary)
                Spacer()
            }.padding().frame(maxWidth: .infinity).background(Color(red: 0.96, green: 0.98, blue: 0.96))
                .navigationTitle(word("progress"))
        }
    }

    private var profileView: some View {
        NavigationStack {
            Form {
                Section("THELingo") {
                    Text("👤 \(profileName)")
                    Text("🎂 \(birthDate)")
                    Picker("Language / Язык", selection: $selectedLanguage) {
                        ForEach(AppLanguage.allCases) { Text($0.rawValue).tag($0.rawValue) }
                    }
                }
                Section {
                    Button("Reset learning progress", role: .destructive) {
                        totalXP = 0
                        completedLessons = 0
                        completedCourseIDs = ""
                    }
                }
            }.navigationTitle(word("profile"))
        }
    }

    private func lessonView(_ lesson: Lesson) -> some View {
        NavigationStack {
            VStack(spacing: 22) {
                Text("✨").font(.system(size: 46))
                Text(t(lesson.title)).font(.title.bold())
                Text(t(lesson.prompt)).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
                ForEach(lesson.options, id: \.self) { option in
                    Button {
                        selectedAnswer = option
                        showResult = true
                    } label: {
                        HStack {
                            Text(option).font(.headline)
                            Spacer()
                            if selectedAnswer == option { Image(systemName: "checkmark.circle.fill") }
                        }.padding().background(selectedAnswer == option ? Color.green.opacity(0.18) : Color.gray.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }.buttonStyle(.plain).disabled(lessonFinished)
                }
                if showResult {
                    Text(selectedAnswer == lesson.answer ? word("correct") : word("wrong"))
                        .font(.headline).foregroundStyle(selectedAnswer == lesson.answer ? .green : .orange)
                    if selectedAnswer == lesson.answer {
                        Button(word("done")) {
                            if !lessonFinished {
                                let earned = 10 * multiplier
                                totalXP += earned
                                completedLessons += 1
                                lessonFinished = true
                            }
                            activeLesson = nil
                            selectedAnswer = ""
                            showResult = false
                            lessonFinished = false
                        }.buttonStyle(.borderedProminent)
                    } else {
                        Button("Try again") { selectedAnswer = ""; showResult = false }.buttonStyle(.bordered)
                    }
                }
                Spacer()
            }.padding().navigationTitle("THELingo").navigationBarTitleDisplayMode(.inline)
        }
    }
}
