
import SwiftUI

// MARK: - Languages

enum AppLanguage: String, CaseIterable, Identifiable {
    case en = "EN"
    case ru = "RU"
    case es = "SP"
    case zh = "CH"
    case ja = "JP"

    var id: String { rawValue }
}

enum StudyCourse: String, CaseIterable, Identifiable {
    case english, spanish, japanese, chinese, russian

    var id: String { rawValue }

    var flag: String {
        switch self {
        case .english: "🇬🇧"
        case .spanish: "🇪🇸"
        case .japanese: "🇯🇵"
        case .chinese: "🇨🇳"
        case .russian: "🇷🇺"
        }
    }

    func title(_ language: AppLanguage) -> String {
        switch self {
        case .english:
            ["EN":"English","RU":"Английский","SP":"Inglés","CH":"英语","JP":"英語"][language.rawValue]!
        case .spanish:
            ["EN":"Spanish","RU":"Испанский","SP":"Español","CH":"西班牙语","JP":"スペイン語"][language.rawValue]!
        case .japanese:
            ["EN":"Japanese","RU":"Японский","SP":"Japonés","CH":"日语","JP":"日本語"][language.rawValue]!
        case .chinese:
            ["EN":"Chinese","RU":"Китайский","SP":"Chino","CH":"中文","JP":"中国語"][language.rawValue]!
        case .russian:
            ["EN":"Russian","RU":"Русский","SP":"Ruso","CH":"俄语","JP":"ロシア語"][language.rawValue]!
        }
    }

    var targetLanguage: AppLanguage {
        switch self {
        case .english: .en
        case .spanish: .es
        case .japanese: .ja
        case .chinese: .zh
        case .russian: .ru
        }
    }
}

// MARK: - Vocabulary

struct Word {
    let translations: [AppLanguage: String]

    func get(_ language: AppLanguage) -> String {
        translations[language] ?? ""
    }
}

let vocabulary: [Word] = [
    Word(translations: [.en:"Hello",.ru:"Привет",.es:"Hola",.zh:"你好",.ja:"こんにちは"]),
    Word(translations: [.en:"Goodbye",.ru:"Пока",.es:"Adiós",.zh:"再见",.ja:"さようなら"]),
    Word(translations: [.en:"Thank you",.ru:"Спасибо",.es:"Gracias",.zh:"谢谢",.ja:"ありがとう"]),
    Word(translations: [.en:"Please",.ru:"Пожалуйста",.es:"Por favor",.zh:"请",.ja:"お願いします"]),
    Word(translations: [.en:"Water",.ru:"Вода",.es:"Agua",.zh:"水",.ja:"水"]),
    Word(translations: [.en:"Bread",.ru:"Хлеб",.es:"Pan",.zh:"面包",.ja:"パン"]),
    Word(translations: [.en:"Apple",.ru:"Яблоко",.es:"Manzana",.zh:"苹果",.ja:"りんご"]),
    Word(translations: [.en:"House",.ru:"Дом",.es:"Casa",.zh:"房子",.ja:"家"]),
    Word(translations: [.en:"School",.ru:"Школа",.es:"Escuela",.zh:"学校",.ja:"学校"]),
    Word(translations: [.en:"Book",.ru:"Книга",.es:"Libro",.zh:"书",.ja:"本"]),
    Word(translations: [.en:"Friend",.ru:"Друг",.es:"Amigo",.zh:"朋友",.ja:"友達"]),
    Word(translations: [.en:"Family",.ru:"Семья",.es:"Familia",.zh:"家庭",.ja:"家族"]),
    Word(translations: [.en:"Cat",.ru:"Кот",.es:"Gato",.zh:"猫",.ja:"猫"]),
    Word(translations: [.en:"Dog",.ru:"Собака",.es:"Perro",.zh:"狗",.ja:"犬"]),
    Word(translations: [.en:"Red",.ru:"Красный",.es:"Rojo",.zh:"红色",.ja:"赤"]),
    Word(translations: [.en:"Green",.ru:"Зелёный",.es:"Verde",.zh:"绿色",.ja:"緑"]),
    Word(translations: [.en:"Blue",.ru:"Синий",.es:"Azul",.zh:"蓝色",.ja:"青"]),
    Word(translations: [.en:"One",.ru:"Один",.es:"Uno",.zh:"一",.ja:"一"]),
    Word(translations: [.en:"Two",.ru:"Два",.es:"Dos",.zh:"二",.ja:"二"]),
    Word(translations: [.en:"Three",.ru:"Три",.es:"Tres",.zh:"三",.ja:"三"]),
    Word(translations: [.en:"Good",.ru:"Хороший",.es:"Bueno",.zh:"好",.ja:"良い"]),
    Word(translations: [.en:"Big",.ru:"Большой",.es:"Grande",.zh:"大",.ja:"大きい"]),
    Word(translations: [.en:"Small",.ru:"Маленький",.es:"Pequeño",.zh:"小",.ja:"小さい"]),
    Word(translations: [.en:"Today",.ru:"Сегодня",.es:"Hoy",.zh:"今天",.ja:"今日"]),
    Word(translations: [.en:"Tomorrow",.ru:"Завтра",.es:"Mañana",.zh:"明天",.ja:"明日"]),
    Word(translations: [.en:"I",.ru:"Я",.es:"Yo",.zh:"我",.ja:"私"]),
    Word(translations: [.en:"You",.ru:"Ты",.es:"Tú",.zh:"你",.ja:"あなた"]),
    Word(translations: [.en:"Eat",.ru:"Есть",.es:"Comer",.zh:"吃",.ja:"食べる"]),
    Word(translations: [.en:"Read",.ru:"Читать",.es:"Leer",.zh:"读",.ja:"読む"]),
    Word(translations: [.en:"Learn",.ru:"Учиться",.es:"Aprender",.zh:"学习",.ja:"学ぶ"])
]

// MARK: - Sentences

struct Sentence {
    let translations: [AppLanguage: String]

    func get(_ language: AppLanguage) -> String {
        translations[language] ?? ""
    }
}

let sentences: [Sentence] = [
    Sentence(translations: [.en:"I like apples",.ru:"Я люблю яблоки",.es:"Me gustan las manzanas",.zh:"我喜欢苹果",.ja:"私はりんごが好きです"]),
    Sentence(translations: [.en:"The cat is small",.ru:"Кот маленький",.es:"El gato es pequeño",.zh:"猫很小",.ja:"猫は小さいです"]),
    Sentence(translations: [.en:"I read a book",.ru:"Я читаю книгу",.es:"Leo un libro",.zh:"我读一本书",.ja:"私は本を読みます"]),
    Sentence(translations: [.en:"I drink water",.ru:"Я пью воду",.es:"Bebo agua",.zh:"我喝水",.ja:"私は水を飲みます"]),
    Sentence(translations: [.en:"This is my house",.ru:"Это мой дом",.es:"Esta es mi casa",.zh:"这是我的家",.ja:"これは私の家です"]),
    Sentence(translations: [.en:"We learn every day",.ru:"Мы учимся каждый день",.es:"Aprendemos todos los días",.zh:"我们每天学习",.ja:"私たちは毎日勉強します"])
]

// MARK: - Helpers

func clean(_ value: String) -> String {
    value.lowercased()
        .trimmingCharacters(in: .whitespacesAndNewlines)
        .replacingOccurrences(of: ".", with: "")
        .replacingOccurrences(of: "!", with: "")
        .replacingOccurrences(of: "?", with: "")
        .replacingOccurrences(of: "。", with: "")
        .replacingOccurrences(of: ",", with: "")
        .replacingOccurrences(of: "，", with: "")
}

func makeOptions(correct: String, language: AppLanguage) -> [String] {
    let alternatives = vocabulary
        .map { $0.get(language) }
        .filter { clean($0) != clean(correct) }

    return (Array(alternatives.shuffled().prefix(3)) + [correct]).shuffled()
}

func todayKey() -> String {
    let formatter = DateFormatter()
    formatter.calendar = Calendar.current
    formatter.locale = Locale(identifier: "en_US_POSIX")
    formatter.dateFormat = "yyyy-MM-dd"
    return formatter.string(from: Date())
}

func yesterdayKey() -> String {
    let yesterday = Calendar.current.date(
        byAdding: .day,
        value: -1,
        to: Calendar.current.startOfDay(for: Date())
    ) ?? Date()

    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd"
    return formatter.string(from: yesterday)
}

// MARK: - Main View

struct ContentView: View {
    @AppStorage("profileName") var profileName = ""
    @AppStorage("didRegister") var didRegister = false
    @AppStorage("birthDate") var birthDate = ""
    @AppStorage("totalXP") var totalXP = 0
    @AppStorage("completedIDs") var completedIDs = ""
    @AppStorage("appLanguage") var appLanguage = "EN"

    @AppStorage("currentStreak") var currentStreak = 0
    @AppStorage("bestStreak") var bestStreak = 0
    @AppStorage("lastStudyDate") var lastStudyDate = ""

    @State private var nameInput = ""
    @State private var birthInput = Date()

    private var language: AppLanguage {
        AppLanguage(rawValue: appLanguage) ?? .en
    }

    private var completed: Set<String> {
        Set(completedIDs.split(separator: ",").map(String.init))
    }

    private var boost: Int {
        completed.count >= 6 ? 3 : completed.count >= 3 ? 2 : 1
    }

    var body: some View {
        Group {
            if didRegister {
                MainTabs(
                    language: language,
                    name: profileName
                )
            } else {
                registration
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        .tint(.green)
        .preferredColorScheme(.light)
        .onAppear {
            refreshStreak()
        }
    }

    private var registration: some View {
        VStack(spacing: 22) {
            Spacer()

            Text("🌱")
                .font(.system(size: 65))

            Text("THELingo")
                .font(.system(size: 38, weight: .heavy))

            Text("Create your profile")
                .font(.title2.bold())

            TextField("Your name", text: $nameInput)
                .textFieldStyle(.roundedBorder)

            DatePicker(
                "Date of birth",
                selection: $birthInput,
                displayedComponents: .date
            )

            Picker("Language", selection: $appLanguage) {
                ForEach(AppLanguage.allCases) {
                    Text($0.rawValue).tag($0.rawValue)
                }
            }
            .pickerStyle(.segmented)

            Button("Continue") {
                let name = nameInput.trimmingCharacters(in: .whitespaces)
                guard !name.isEmpty else { return }

                profileName = name
                birthDate = birthInput.formatted(date: .numeric, time: .omitted)
                didRegister = true
            }
            .buttonStyle(.borderedProminent)
            .disabled(nameInput.trimmingCharacters(in: .whitespaces).isEmpty)

            Spacer()
        }
        .padding(25)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func refreshStreak() {
        guard !lastStudyDate.isEmpty else { return }

        if lastStudyDate != todayKey() && lastStudyDate != yesterdayKey() {
            currentStreak = 0
        }
    }
}

// MARK: - Main Tabs

struct MainTabs: View {
    let language: AppLanguage
    let name: String

    @AppStorage("totalXP") var totalXP = 0
    @AppStorage("completedIDs") var completedIDs = ""
    @AppStorage("currentStreak") var currentStreak = 0
    @AppStorage("bestStreak") var bestStreak = 0
    @AppStorage("lastStudyDate") var lastStudyDate = ""

    private var completed: Set<String> {
        Set(completedIDs.split(separator: ",").map(String.init))
    }

    private var boost: Int {
        completed.count >= 6 ? 3 : completed.count >= 3 ? 2 : 1
    }

    var body: some View {
        TabView {
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Hey! \(name) 👋")
                                    .font(.largeTitle.bold())

                                Text("Choose your course")
                                    .foregroundStyle(.secondary)
                            }

                            Spacer()

                            Text("🌱")
                                .font(.system(size: 38))
                        }

                        streakCard

                        HStack(spacing: 12) {
                            statCard("⭐", "\(totalXP)", "XP")
                            statCard("⚡", "×\(boost)", "XP BOOST")
                        }

                        Text("Your courses")
                            .font(.title2.bold())

                        ForEach(StudyCourse.allCases) { course in
                            NavigationLink {
                                CourseView(
                                    course: course,
                                    language: language
                                )
                            } label: {
                                HStack(spacing: 15) {
                                    Text(course.flag)
                                        .font(.system(size: 42))

                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(course.title(language))
                                            .font(.title3.bold())
                                            .foregroundStyle(.primary)

                                        Text("1,024 lessons · 4 tasks each")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }

                                    Spacer()

                                    Image(systemName: "chevron.right")
                                        .foregroundStyle(.secondary)
                                }
                                .padding()
                                .background(Color(uiColor: .secondarySystemGroupedBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 18))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding()
                }
                .background(Color(uiColor: .systemGroupedBackground))
                .toolbar(.hidden, for: .navigationBar)
            }
            .tabItem {
                Label("Выбор курсов", systemImage: "map.fill")
            }

            NavigationStack {
                ScrollView {
                    VStack(spacing: 18) {
                        Text("🏆")
                            .font(.system(size: 65))

                        Text("Your progress")
                            .font(.largeTitle.bold())

                        Text("\(totalXP) XP")
                            .font(.system(size: 42, weight: .heavy))
                            .foregroundStyle(.green)

                        Text("\(completed.count) lessons completed")
                            .foregroundStyle(.secondary)

                        streakCard

                        statCard("⚡", "×\(boost)", "XP BOOST")
                            .frame(maxWidth: .infinity)

                        Text("3 lessons = ×2 XP\n6 lessons = ×3 XP")
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                }
                .background(Color(uiColor: .systemGroupedBackground))
                .navigationTitle("Progress")
            }
            .tabItem {
                Label("Прогресс", systemImage: "chart.bar.fill")
            }

            NavigationStack {
                Form {
                    Text("👤 \(name)")
                    Text("Language: \(language.rawValue)")
                    Text("Current streak: \(currentStreak) days")
                    Text("Best streak: \(bestStreak) days")
                }
                .navigationTitle("Profile")
            }
            .tabItem {
                Label("Профиль", systemImage: "person.fill")
            }
        }
        .tint(.green)
    }

    private var streakCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("DAYS IN A ROW")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Text("\(currentStreak)")
                            .font(.system(size: 38, weight: .heavy))

                        Text("🔥")
                            .font(.system(size: 30))
                    }
                }

                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("BEST")
                        .font(.caption.bold())
                        .foregroundStyle(.secondary)

                    Text("\(bestStreak) days")
                        .font(.headline)
                }
            }

            HStack(spacing: 0) {
                ForEach(weekDays(), id: \.date) { day in
                    VStack(spacing: 8) {
                        Text(day.name)
                            .font(.caption2)
                            .foregroundStyle(.secondary)

                        ZStack {
                            Circle()
                                .fill(day.isStudied ? Color.orange.opacity(0.18) : Color.gray.opacity(0.10))
                                .frame(width: 34, height: 34)

                            if day.isStudied {
                                Text("🔥")
                                    .font(.system(size: 18))
                            } else {
                                Text(day.number)
                                    .font(.caption.bold())
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .padding()
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    private func statCard(_ emoji: String, _ value: String, _ title: String) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(emoji).font(.title)
            Text(value).font(.largeTitle.bold())
            Text(title).font(.caption.bold()).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func weekDays() -> [(date: String, name: String, number: String, isStudied: Bool)] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let weekday = calendar.component(.weekday, from: today)
        let mondayOffset = (weekday + 5) % 7
        let monday = calendar.date(byAdding: .day, value: -mondayOffset, to: today) ?? today

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"

        let names = ["M", "T", "W", "T", "F", "S", "S"]

        return (0..<7).compactMap { index in
            guard let date = calendar.date(byAdding: .day, value: index, to: monday) else {
                return nil
            }

            let key = formatter.string(from: date)
            let isTodayOrPast = date <= today
            let studied = lastStudyDate == key || (date < today && isTodayOrPast && false)

            return (
                date: key,
                name: names[index],
                number: String(calendar.component(.day, from: date)),
                isStudied: studied
            )
        }
    }
}

// MARK: - Course Map

struct CourseView: View {
    let course: StudyCourse
    let language: AppLanguage

    @AppStorage("completedIDs") var completedIDs = ""

    private var completed: Set<String> {
        Set(completedIDs.split(separator: ",").map(String.init))
    }

    private let columns = [
        GridItem(.flexible())
    ]

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(spacing: 18) {
                    courseHeader

                    ForEach(0..<103, id: \.self) { section in
                        VStack(spacing: 12) {
                            HStack {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("UNIT \(section + 1)")
                                        .font(.caption.bold())
                                        .foregroundStyle(.green)

                                    Text(sectionTitle(section))
                                        .font(.title3.bold())
                                }

                                Spacer()

                                Text("\(section * 10 + 1)–\(min((section + 1) * 10, 1024))")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            .padding(.horizontal)

                            ForEach(1...min(10, 1024 - section * 10), id: \.self) { offset in
                                let number = section * 10 + offset
                                lessonNode(number)
                                    .id(number)
                            }
                        }
                        .padding(.vertical, 12)
                    }
                }
                .padding(.vertical)
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .navigationTitle(course.title(language))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Text(course.flag)
                        .font(.title2)
                }
            }
            .onAppear {
                let next = firstIncompleteLesson()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    proxy.scrollTo(next, anchor: .center)
                }
            }
        }
    }

    private var courseHeader: some View {
        VStack(spacing: 10) {
            Text(course.flag)
                .font(.system(size: 55))

            Text(course.title(language))
                .font(.largeTitle.bold())

            Text("\(completed.filter { $0.hasPrefix(course.rawValue + "-") }.count) / 1024 lessons")
                .foregroundStyle(.secondary)

            ProgressView(
                value: Double(completed.filter { $0.hasPrefix(course.rawValue + "-") }.count),
                total: 1024
            )
            .tint(.green)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(uiColor: .secondarySystemGroupedBackground))
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .padding(.horizontal)
    }

    private func lessonNode(_ number: Int) -> some View {
        let id = "\(course.rawValue)-\(number)"
        let isDone = completed.contains(id)
        let isUnlocked = number == 1 || completed.contains("\(course.rawValue)-\(number - 1)")
        let isCurrent = isUnlocked && !isDone

        return HStack {
            if number % 4 == 1 || number % 4 == 2 {
                Spacer()
            }

            NavigationLink {
                LessonView(
                    course: course,
                    language: language,
                    number: number
                )
            } label: {
                VStack(spacing: 5) {
                    ZStack {
                        Circle()
                            .fill(nodeColor(done: isDone, unlocked: isUnlocked))
                            .frame(width: 68, height: 68)

                        Circle()
                            .stroke(.white.opacity(0.9), lineWidth: 4)
                            .frame(width: 60, height: 60)

                        if isDone {
                            Image(systemName: "checkmark")
                                .font(.system(size: 26, weight: .heavy))
                                .foregroundStyle(.white)
                        } else if !isUnlocked {
                            Image(systemName: "lock.fill")
                                .font(.system(size: 22, weight: .bold))
                                .foregroundStyle(.white.opacity(0.9))
                        } else {
                            Image(systemName: number % 10 == 0 ? "trophy.fill" : "star.fill")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundStyle(.white)
                        }
                    }

                    Text("Lesson \(number)")
                        .font(.caption.bold())
                        .foregroundStyle(.primary)

                    if isCurrent {
                        Text("START")
                            .font(.system(size: 9, weight: .heavy))
                            .foregroundStyle(.green)
                    }
                }
            }
            .buttonStyle(.plain)
            .disabled(!isUnlocked)

            if number % 4 == 1 || number % 4 == 2 {
                Spacer()
            }
        }
        .padding(.horizontal, 35)
        .frame(maxWidth: .infinity)
    }

    private func nodeColor(done: Bool, unlocked: Bool) -> Color {
        if done { return .green }
        if unlocked { return .orange }
        return .gray.opacity(0.45)
    }

    private func sectionTitle(_ section: Int) -> String {
        switch section {
        case 0: "Getting started"
        case 1...4: "Basic vocabulary"
        case 5...14: "Building sentences"
        case 15...29: "Grammar and conversation"
        case 30...49: "Intermediate"
        case 50...74: "Advanced practice"
        case 75...89: "Fluent communication"
        default: "Expert challenges"
        }
    }

    private func firstIncompleteLesson() -> Int {
        for number in 1...1024 {
            if !completed.contains("\(course.rawValue)-\(number)") {
                return number
            }
        }
        return 1024
    }
}

// MARK: - Lesson

struct LessonView: View {
    let course: StudyCourse
    let language: AppLanguage
    let number: Int

    @AppStorage("totalXP") var totalXP = 0
    @AppStorage("completedIDs") var completedIDs = ""

    @AppStorage("currentStreak") var currentStreak = 0
    @AppStorage("bestStreak") var bestStreak = 0
    @AppStorage("lastStudyDate") var lastStudyDate = ""

    @Environment(\.dismiss) var dismiss

    @State private var taskIndex = 0
    @State private var answer = ""
    @State private var selected = ""
    @State private var builtWords: [String] = []
    @State private var shuffledParts: [String] = []
    @State private var optionList: [String] = []
    @State private var checked = false
    @State private var correct = false
    @State private var finished = false

    private var word: Word {
        vocabulary[(number * 3 + taskIndex) % vocabulary.count]
    }

    private var sentence: Sentence {
        sentences[(number + taskIndex) % sentences.count]
    }

    private var source: String {
        word.get(course.targetLanguage)
    }

    private var translation: String {
        word.get(language)
    }

    private var sourceSentence: String {
        sentence.get(course.targetLanguage)
    }

    private var translatedSentence: String {
        sentence.get(language)
    }

    private var lessonID: String {
        "\(course.rawValue)-\(number)"
    }

    private var sentenceParts: [String] {
        sourceSentence.components(separatedBy: " ")
    }

    private var isWordBasedSentence: Bool {
        sentenceParts.count > 1
    }

    private var expected: String {
        switch taskIndex {
        case 0, 1: translation
        case 2: sourceSentence
        default: translatedSentence
        }
    }

    private var currentAnswer: String {
        switch taskIndex {
        case 0: selected
        case 2 where isWordBasedSentence: builtWords.joined(separator: " ")
        default: answer
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                        .font(.headline)
                        .foregroundStyle(.secondary)
                        .padding(10)
                        .background(Color.gray.opacity(0.12))
                        .clipShape(Circle())
                }

                ProgressView(value: Double(taskIndex + 1), total: 4)
                    .tint(.green)

                Text("\(taskIndex + 1)/4")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
            }
            .padding()

            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text(course.flag)
                        .font(.system(size: 48))

                    Text(taskTitle)
                        .font(.largeTitle.bold())

                    Text(taskPrompt)
                        .font(.title3.bold())
                        .fixedSize(horizontal: false, vertical: true)

                    if taskIndex == 0 {
                        ForEach(optionList, id: \.self) { option in
                            Button {
                                selected = option
                            } label: {
                                HStack {
                                    Text(option)
                                        .font(.body.weight(.semibold))

                                    Spacer()

                                    if selected == option {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundStyle(.green)
                                    }
                                }
                                .padding()
                                .frame(maxWidth: .infinity, minHeight: 58)
                                .background(
                                    selected == option
                                    ? Color.green.opacity(0.15)
                                    : Color(uiColor: .secondarySystemGroupedBackground)
                                )
                                .overlay {
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(
                                            selected == option ? Color.green : Color.gray.opacity(0.15),
                                            lineWidth: 2
                                        )
                                }
                                .clipShape(RoundedRectangle(cornerRadius: 15))
                            }
                            .buttonStyle(.plain)
                        }
                    } else if taskIndex == 2 && isWordBasedSentence {
                        Text(builtWords.joined(separator: " "))
                            .font(.title3)
                            .frame(maxWidth: .infinity, minHeight: 65)
                            .padding()
                            .background(Color(uiColor: .secondarySystemGroupedBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 15))

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                            ForEach(Array(shuffledParts.enumerated()), id: \.offset) { index, part in
                                Button {
                                    guard !builtWords.contains(part) else { return }
                                    builtWords.append(part)
                                } label: {
                                    Text(part)
                                        .frame(maxWidth: .infinity, minHeight: 48)
                                        .background(
                                            builtWords.contains(part)
                                            ? Color.gray.opacity(0.15)
                                            : Color.green.opacity(0.12)
                                        )
                                        .clipShape(RoundedRectangle(cornerRadius: 12))
                                }
                                .disabled(builtWords.contains(part))
                                .buttonStyle(.plain)
                            }
                        }

                        Button("Clear") {
                            builtWords = []
                        }
                        .foregroundStyle(.red)
                    } else {
                        TextField("Write your answer...", text: $answer, axis: .vertical)
                            .font(.title3)
                            .padding()
                            .background(Color(uiColor: .secondarySystemGroupedBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 15))
                            .lineLimit(2...4)
                    }

                    if checked {
                        Text(correct ? "Correct! 🎉" : "Try again!")
                            .font(.headline)
                            .foregroundStyle(correct ? .green : .orange)

                        if !correct {
                            Text("Correct answer: \(expected)")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding()
            }

            VStack {
                if finished {
                    Button("Back to course") {
                        dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .frame(maxWidth: .infinity)
                } else if checked && correct {
                    Button(taskIndex == 3 ? "Finish lesson" : "Continue") {
                        if taskIndex == 3 {
                            finishLesson()
                        } else {
                            nextTask()
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .frame(maxWidth: .infinity)
                } else {
                    Button("Check answer") {
                        correct = clean(currentAnswer) == clean(expected)
                        checked = true
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .frame(maxWidth: .infinity)
                    .disabled(currentAnswer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .padding()
            .background(Color(uiColor: .systemBackground))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
        .navigationTitle("THELingo")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden()
        .onAppear {
            if completedIDs.split(separator: ",").contains(Substring(lessonID)) {
                finished = true
            }
            prepareTask()
        }
    }

    private var taskTitle: String {
        switch taskIndex {
        case 0: "Choose the translation"
        case 1: "Write the word"
        case 2: "Build the sentence"
        default: "Translate the sentence"
        }
    }

    private var taskPrompt: String {
        switch taskIndex {
        case 0: "What does \(source) mean?"
        case 1: "Write the translation of: \(source)"
        case 2: "Put the words in the correct order: \(sourceSentence)"
        default: "Translate into \(language.rawValue): \(sourceSentence)"
        }
    }

    private func prepareTask() {
        optionList = makeOptions(correct: translation, language: language)
        shuffledParts = sentenceParts.shuffled()
    }

    private func nextTask() {
        taskIndex += 1
        answer = ""
        selected = ""
        builtWords = []
        checked = false
        correct = false
        prepareTask()
    }

    private func finishLesson() {
        var ids = Set(completedIDs.split(separator: ",").map(String.init))

        guard !ids.contains(lessonID) else {
            finished = true
            return
        }

        let multiplier = ids.count >= 6 ? 3 : ids.count >= 3 ? 2 : 1

        totalXP += 10 * multiplier
        ids.insert(lessonID)
        completedIDs = ids.sorted().joined(separator: ",")

        updateStreak()
        finished = true
    }

    private func updateStreak() {
        let today = todayKey()

        if lastStudyDate == today {
            return
        }

        if lastStudyDate == yesterdayKey() {
            currentStreak += 1
        } else {
            currentStreak = 1
        }

        bestStreak = max(bestStreak, currentStreak)
        lastStudyDate = today
    }
}
