# THELingo

A SwiftUI language-learning app prototype for iOS.

## Features
- Interface languages: English, Russian, Spanish, Chinese, Japanese.
- Local profile registration with name and date of birth (no email).
- Course list, mini-lessons, XP, and permanent lesson-count multipliers:
  - 0-2 completed lessons: ×1
  - 3-5 completed lessons: ×2
  - 6+ completed lessons: ×3
- Progress is stored locally on the device with `@AppStorage`.

## Build
Open `THELingo.xcodeproj` in Xcode and select the `THELingo` scheme.

Codemagic workflow `thelingo_unsigned_ipa` downloads the GitHub `main` branch archive, builds with code signing disabled, packages the `.app` into `THELingo-unsigned.ipa`, and publishes it as an artifact.

## Important
The IPA is intentionally unsigned. iOS normally requires signing for installation on a physical device. This build is useful as an unsigned build artifact, not a ready-to-install App Store package.
